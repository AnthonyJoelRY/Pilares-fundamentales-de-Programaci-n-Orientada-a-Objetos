package actividad001;

public class Actividad001 {

    public static void main(String[] args) {
        Metodos obj = new Metodos();
        int opc;
        do {
            opc = obj.menu();
            switch (opc) {
                case 1:
                    obj.escribir();
                    break;
                case 2:
                    obj.traer();
                    break;
                default:
                    break;
            }
        } while (opc != 0);

    }

}
