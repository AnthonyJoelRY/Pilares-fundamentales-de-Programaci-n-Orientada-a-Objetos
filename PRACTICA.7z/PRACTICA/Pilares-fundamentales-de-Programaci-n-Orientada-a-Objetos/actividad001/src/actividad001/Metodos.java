package actividad001;

import java.util.*;
import java.io.*;

public class Metodos {

    Scanner entrada;
    File archivo;

    public Metodos() {

        this.entrada = new Scanner(System.in);
        this.archivo = new File("myArchivo.txt");
    }

    public int menu() {
        System.out.println("Escribir datos [1]");
        System.out.println("Leer datos [2]");
        System.out.println("salir [0]");
        return entrada.nextInt();
    }

    public void escribir() {
        FileWriter escribir;
        PrintWriter linea;
        String nombre = "", correo = "", dir = "";
        if (!archivo.exists()) {
            try {
                archivo.createNewFile();
            } catch (Exception e) {

            }
        }
        entrada.nextLine();
        System.out.println("Digite el nombre:");
        nombre = entrada.nextLine();
        System.out.println("Digite el correo:");
        correo = entrada.nextLine();
        System.out.println("Digite la direccion:");
        dir = entrada.nextLine();
        try {
        escribir = new FileWriter (archivo, false);    
        linea = new PrintWriter(escribir,true);
        linea.println (nombre+"\n"+correo+"\n"+dir);
        linea.close();
                
        } catch (Exception e) {
        }
    }

}
